# uinwsskripsi
class skripsi fakultas sains dan teknologi uin walisongo semarang

Petunjuk penggunaan : 
1. https://mmfvlogs.blogspot.com/2021/02/tutorial-penggunaan-class-latex.html
2. https://www.youtube.com/watch?v=Qy2jBs2UG4c&list=PLI3mZmyQJECXgMATk50DYcidw7GQmJuRF&index=4

Tutorial instalasi LaTeX : 
1. https://mmfvlogs.blogspot.com/2021/02/tutorial-instalasi-latex.html
2. Tutorial LaTeX : 4 - Mengetik skripsi dengan LaTeX menggunakan class uinwsskripsi : https://www.youtube.com/watch?v=eX2Z_UJmVwY

Tutorial LaTeX :
1. Tutorial LaTeX : 1 - Class, Tabel (online), Gambar, Enumerate, Itemize : https://www.youtube.com/watch?v=S72joRCb3-0
2. Tutorial LaTeX : 2 - Membuat Bibliography : https://www.youtube.com/watch?v=Yv_3APEcULA
3. Tutorial LaTeX : 3 - Presentasi Beamer: https://www.youtube.com/watch?v=jekLxVIUTIQ
